/**
 * output package name
 */
package com.kingdee.eas.custom.llwebservice.app;

import com.kingdee.bos.Context;
import com.kingdee.eas.framework.batchHandler.RequestContext;
import com.kingdee.eas.framework.batchHandler.ResponseContext;


/**
 * output class name
 */
public abstract class AbstractVoucherBillEditUIHandler extends com.kingdee.eas.framework.app.CoreBillEditUIHandler

{
}