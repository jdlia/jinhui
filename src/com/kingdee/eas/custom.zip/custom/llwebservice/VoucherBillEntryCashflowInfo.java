package com.kingdee.eas.custom.llwebservice;

import java.io.Serializable;

public class VoucherBillEntryCashflowInfo extends AbstractVoucherBillEntryCashflowInfo implements Serializable 
{
    public VoucherBillEntryCashflowInfo()
    {
        super();
    }
    protected VoucherBillEntryCashflowInfo(String pkField)
    {
        super(pkField);
    }
}