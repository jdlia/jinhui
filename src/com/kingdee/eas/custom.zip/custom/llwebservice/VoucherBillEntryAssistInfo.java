package com.kingdee.eas.custom.llwebservice;

import java.io.Serializable;

public class VoucherBillEntryAssistInfo extends AbstractVoucherBillEntryAssistInfo implements Serializable 
{
    public VoucherBillEntryAssistInfo()
    {
        super();
    }
    protected VoucherBillEntryAssistInfo(String pkField)
    {
        super(pkField);
    }
}